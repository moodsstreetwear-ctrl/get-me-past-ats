# GET ME PAST ATS — Product Plan

## Problem

A lot of people apply to dozens or hundreds of jobs and never know whether a human even saw their resume. They do not need vague advice. They need to know what is missing, what looks weak, and what to fix before applying.

## Target users

- Entry-level workers
- Trade workers
- Manufacturing workers
- CDL holders
- People with gaps, career changes, or non-perfect work histories
- People who need a plain-language resume tool instead of corporate resume advice

## Core promise

Paste the job post. Paste your resume. Get told what to fix.

## MVP user flow

1. User pastes resume.
2. User pastes job description.
3. User selects job type.
4. App returns match score.
5. App shows missing keywords.
6. App shows recruiter red flags.
7. App generates stronger wording.
8. User tracks the application.

## Future paid version

### Free tier
- 3 resume scans per week
- Basic score
- Basic keyword gaps
- Local tracker

### Paid tier
- Unlimited scans
- AI rewrites
- PDF upload
- Export tailored resumes
- Follow-up emails
- Interview practice
- Application tracker cloud sync

## Differentiator

Most resume tools sound corporate and generic. This one is for regular people trying to get hired. It should explain things like a real person would:

- “Your dates look confusing.”
- “The job asks for safety, but your resume does not say safety anywhere.”
- “You have the experience, but the wording is not matching the job post.”
- “This bullet is too weak. Say what machine you operated and what you were responsible for.”

## Version 2 feature ideas

- Better overlap detection for work dates
- Resume PDF parser
- Job post URL import
- One-click tailored resume export
- Cover letter generator
- Follow-up email generator
- Rejection reason tracker
- Interview prep mode
- Skills gap training suggestions

## Possible slogan

**Stop applying blind. Make the system read you right.**
